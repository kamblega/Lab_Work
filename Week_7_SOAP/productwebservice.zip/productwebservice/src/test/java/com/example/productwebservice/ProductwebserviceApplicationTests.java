package com.example.productwebservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductwebserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
