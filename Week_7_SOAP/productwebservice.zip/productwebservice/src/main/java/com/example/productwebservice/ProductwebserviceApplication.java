package com.example.productwebservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductwebserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductwebserviceApplication.class, args);
	}

}
