package com.example.consumingwebservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConsumingwebservicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
